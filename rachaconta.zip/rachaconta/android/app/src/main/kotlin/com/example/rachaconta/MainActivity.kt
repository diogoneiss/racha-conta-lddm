package com.example.rachaconta

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
